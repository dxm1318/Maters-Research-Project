function varargout = barumerli2022(varargin)

% This file is licensed unter the GNU General Public License (GPL) either 
% version 3 of the license, or any later version as published by the Free Software 
% Foundation. Details of the GPLv3 can be found in the AMT directory "licences" and 
% at <https://www.gnu.org/licenses/gpl-3.0.html>. 
% You can redistribute this file and/or modify it under the terms of the GPLv3. 
% This file is distributed without any warranty; without even the implied warranty 
% of merchantability or fitness for a particular purpose. 
%
%   Url: http://amtoolbox.org/amt-1.6.0/doc/legacy/barumerli2022.php



    warning(sprintf(['barumerli2022 has been renamed barumerli2023.\n', ...
            'The barumerli2022 scripts are going to be removed with the next update.\n', ...
            'Calling barumerli2023...']))
    varargout = barumerli2023(varargin{:});
end

